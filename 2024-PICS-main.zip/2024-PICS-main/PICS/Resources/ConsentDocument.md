The application collects your survey results to analyze your progress.
